import mongoose from "mongoose";
import TransactionHistory from "../models/transactionHistory.model";
import eventModel from "../models/event.model";
import {
  DashboardRange,
  DashboardDateRange,
  getDashboardDateRange,
  buildDateMatch,
} from "../utils/daterange";

interface TicketSalesDetail {
  eventId: string;
  eventTitle: string;
  ticketTitle: string;
  ticketsSold: number;
  revenue: number;
  ticketPrice: number;
  currency: string;
}

interface TopEventByRevenue {
  eventId: string;
  eventTitle: string;
  revenue: number;
  ticketsSold: number;
}

interface CheckInStats {
  totalSold: number;
  totalCheckedIn: number;
  checkInRate: number; // percentage, 0-100
  eventsConsidered: number; // events whose endDate has passed, within range
}

interface PaymentHealthStats {
  totalCompleted: number;
  totalPending: number;
  totalFailed: number;
  completionRate: number; // percentage of completed among all transactions
}

interface InfluencerStats {
  influencerRevenue: number;
  influencerTickets: number;
  organicRevenue: number;
  organicTickets: number;
  influencerRevenueSharePercent: number; // % of total revenue attributed to influencers
}

interface TicketSaleWindowStats {
  onSale: number; // currently purchasable
  notYetOpen: number; // saleStartDate is in the future
  closed: number; // saleEndDate has passed
  noWindowSet: number; // no sale window configured (always open)
}

interface MetricWithChange {
  value: number;
  changePercent: number | null;
}

interface TrendPoint {
  label: string;
  revenue: number;
  tickets: number;
}

interface AnalyticsResult {
  range?: DashboardRange;
  totalRevenue?: number;
  totalTickets?: number;
  totalEvents?: number;
  totalPublishedEvents?: number;
  totalCompletedTransactions?: number;
  avgOrderValue?: number;
  avgTicketsPerOrder?: number;
  ticketSalesDetails?: TicketSalesDetail[];
  topEventsByRevenue?: TopEventByRevenue[];
  checkInStats?: CheckInStats;
  paymentHealth?: PaymentHealthStats;
  influencerStats?: InfluencerStats;
  ticketSaleWindowStats?: TicketSaleWindowStats;
  revenue?: MetricWithChange;
  tickets?: MetricWithChange;
  conversion?: MetricWithChange;
  trend?: TrendPoint[];
}

const MONTH_LABELS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export class AnalyticsService {
  private transactionModel = TransactionHistory;
  private eventModel = eventModel;

  constructor() {}

  private async ensureConnection() {
    if (mongoose.connection.readyState === 0) {
      throw new Error("Database not connected");
    }
  }

  // ==================== HELPER FUNCTIONS ====================
  private percentChange(current: number, previous: number | null): number | null {
    if (previous === null) return null;
    if (previous === 0) return current > 0 ? 100 : 0;
    return ((current - previous) / previous) * 100;
  }

  /**
   * Picks how to bucket the revenue/tickets trend chart based on the
   * selected range — a flat "month vs year" toggle doesn't make sense
   * anymore now that range is flexible, so granularity scales with
   * window size: daily within a month, weekly within 3 months,
   * monthly within a year, yearly for all-time.
   */
  private getTrendGrouping(range: DashboardRange) {
    switch (range) {
      case "month":
        return {
          groupId: {
            year: { $year: "$createdAt" },
            month: { $month: "$createdAt" },
            day: { $dayOfMonth: "$createdAt" },
          },
          label: (id: any) => `${id.day}`,
          sort: { "_id.year": 1, "_id.month": 1, "_id.day": 1 } as Record<string, 1>,
        };
      case "3months":
        return {
          groupId: {
            year: { $isoWeekYear: "$createdAt" },
            week: { $isoWeek: "$createdAt" },
          },
          label: (id: any) => `Wk ${id.week}`,
          sort: { "_id.year": 1, "_id.week": 1 } as Record<string, 1>,
        };
      case "year":
        return {
          groupId: {
            year: { $year: "$createdAt" },
            month: { $month: "$createdAt" },
          },
          label: (id: any) => MONTH_LABELS[id.month - 1] ?? `${id.month}`,
          sort: { "_id.year": 1, "_id.month": 1 } as Record<string, 1>,
        };
      case "all":
      default:
        return {
          groupId: { year: { $year: "$createdAt" } },
          label: (id: any) => `${id.year}`,
          sort: { "_id.year": 1 } as Record<string, 1>,
        };
    }
  }

  // ==================== TICKET SALES DETAILS ====================
  /**
   * Detailed ticket sales (revenue + count per ticket type), scoped
   * to a date window. Pass `window: null` for no lower bound (i.e.
   * all-time).
   */
  public async getTicketSalesDetails(
    window: DashboardDateRange["current"] | null = null
  ): Promise<TicketSalesDetail[]> {
    await this.ensureConnection();

    const dateMatch = window ? buildDateMatch("createdAt", window) : null;

    const salesData = await this.transactionModel.aggregate([
      { $match: { status: "completed", ...(dateMatch || {}) } },
      {
        $lookup: {
          from: "events",
          localField: "event",
          foreignField: "_id",
          as: "eventData",
        },
      },
      { $unwind: "$eventData" },
      { $unwind: "$eventData.tickets" },
      {
        // Match each transaction to the *specific* ticket type it was
        // bought for, by the ticket's real ObjectId.
        $match: {
          $expr: {
            $eq: ["$ticket", "$eventData.tickets._id"],
          },
        },
      },
      {
        $project: {
          eventId: "$event",
          eventTitle: "$eventData.eventDetails.eventTitle",
          ticketTitle: "$eventData.tickets.ticketName",
          ticketPrice: "$eventData.tickets.price",
          currency: "$eventData.tickets.currency",
          ticketsSold: { $size: "$buyers" },
          revenue: {
            $multiply: [{ $size: "$buyers" }, "$eventData.tickets.price"],
          },
        },
      },
      {
        $group: {
          _id: {
            eventId: "$eventId",
            eventTitle: "$eventTitle",
            ticketTitle: "$ticketTitle",
            ticketPrice: "$ticketPrice",
            currency: "$currency",
          },
          ticketsSold: { $sum: "$ticketsSold" },
          revenue: { $sum: "$revenue" },
        },
      },
      {
        $project: {
          _id: 0,
          eventId: { $toString: "$_id.eventId" },
          eventTitle: "$_id.eventTitle",
          ticketTitle: "$_id.ticketTitle",
          ticketPrice: "$_id.ticketPrice",
          currency: "$_id.currency",
          ticketsSold: 1,
          revenue: 1,
        },
      },
      { $sort: { revenue: -1 } },
    ]);

    return salesData;
  }

  // ==================== CORE ANALYTICS METHODS ====================
  public async getEventTicketStats(
    dateRange: DashboardDateRange
  ): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const ticketSalesDetails = await this.getTicketSalesDetails(dateRange.current);

    const totalTickets = ticketSalesDetails.reduce((acc, item) => acc + item.ticketsSold, 0);
    const totalRevenue = ticketSalesDetails.reduce((acc, item) => acc + item.revenue, 0);

    const uniqueEvents = new Set(ticketSalesDetails.map((item) => item.eventId));
    const totalEvents = uniqueEvents.size;

    // Published events created within the selected window (for "all"
    // this is every published event ever, matching the old behavior).
    const publishedMatch: any = { published: true };
    const createdAtMatch = buildDateMatch("createdAt", dateRange.current);
    if (createdAtMatch) Object.assign(publishedMatch, createdAtMatch);
    const totalPublishedEvents = await this.eventModel.countDocuments(publishedMatch);

    // Roll ticket-tier-level sales up to event-level, ranked by
    // revenue (not just ticket count).
    const eventTotals = new Map<string, TopEventByRevenue>();
    for (const item of ticketSalesDetails) {
      const existing = eventTotals.get(item.eventId);
      if (existing) {
        existing.revenue += item.revenue;
        existing.ticketsSold += item.ticketsSold;
      } else {
        eventTotals.set(item.eventId, {
          eventId: item.eventId,
          eventTitle: item.eventTitle,
          revenue: item.revenue,
          ticketsSold: item.ticketsSold,
        });
      }
    }
    const topEventsByRevenue = Array.from(eventTotals.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    const transactionDateMatch = buildDateMatch("createdAt", dateRange.current);
    const totalCompletedTransactions = await this.transactionModel.countDocuments({
      status: "completed",
      ...(transactionDateMatch || {}),
    });

    const avgOrderValue =
      totalCompletedTransactions > 0 ? totalRevenue / totalCompletedTransactions : 0;
    const avgTicketsPerOrder =
      totalCompletedTransactions > 0 ? totalTickets / totalCompletedTransactions : 0;

    return {
      totalEvents,
      totalTickets,
      totalRevenue,
      totalPublishedEvents,
      totalCompletedTransactions,
      avgOrderValue: Number(avgOrderValue.toFixed(2)),
      avgTicketsPerOrder: Number(avgTicketsPerOrder.toFixed(2)),
      ticketSalesDetails,
      topEventsByRevenue,
    };
  }

  // ==================== REVENUE / TICKETS (RANGE-AWARE, WITH TREND) ====================
  /**
   * Revenue + tickets sold for the selected range, compared against
   * the equivalent prior window — same comparison model as the
   * dashboard. "all" has no prior window, so changePercent is null
   * rather than a fabricated number.
   */
  public async getRevenueAndTicketsStats(
    dateRange: DashboardDateRange
  ): Promise<AnalyticsResult> {
    await this.ensureConnection();

    // Ticket count never actually needs the event/ticket join — it's
    // just buyers.length summed across completed transactions, same
    // as the dashboard's calculation. Keeping it join-free matters:
    // if an event is later deleted, its transaction records aren't
    // cascade-deleted (see eventService.deleteEvent), so a join-based
    // count would silently drop those tickets while the dashboard's
    // simple count wouldn't — producing two different "tickets sold"
    // numbers for what should be the same figure.
    const countTicketsForWindow = async (window: DashboardDateRange["current"] | null) => {
      if (!window) return 0;

      const dateMatch = buildDateMatch("createdAt", window);
      const [result] = await this.transactionModel.aggregate([
        { $match: { status: "completed", ...(dateMatch || {}) } },
        { $group: { _id: null, tickets: { $sum: { $size: "$buyers" } } } },
      ]);

      return result?.tickets || 0;
    };

    // Revenue genuinely needs the ticket's price, so it does require
    // the join — and will under-count for orphaned transactions
    // (deleted events/tickets) since there's no price to attribute
    // them to. That's an inherent limitation of revenue specifically,
    // not a bug to "fix" the same way the ticket count was.
    const sumRevenueForWindow = async (window: DashboardDateRange["current"] | null) => {
      if (!window) return 0;

      const dateMatch = buildDateMatch("createdAt", window);
      const [result] = await this.transactionModel.aggregate([
        { $match: { status: "completed", ...(dateMatch || {}) } },
        {
          $lookup: {
            from: "events",
            localField: "event",
            foreignField: "_id",
            as: "eventData",
          },
        },
        { $unwind: "$eventData" },
        { $unwind: "$eventData.tickets" },
        { $match: { $expr: { $eq: ["$ticket", "$eventData.tickets._id"] } } },
        {
          $group: {
            _id: null,
            revenue: {
              $sum: { $multiply: [{ $size: "$buyers" }, "$eventData.tickets.price"] },
            },
          },
        },
      ]);

      return result?.revenue || 0;
    };

    const [currentTickets, previousTickets, currentRevenue, previousRevenue] =
      await Promise.all([
        countTicketsForWindow(dateRange.current),
        dateRange.previous ? countTicketsForWindow(dateRange.previous) : Promise.resolve(null),
        sumRevenueForWindow(dateRange.current),
        dateRange.previous ? sumRevenueForWindow(dateRange.previous) : Promise.resolve(null),
      ]);

    return {
      revenue: {
        value: currentRevenue,
        changePercent:
          previousRevenue !== null ? this.percentChange(currentRevenue, previousRevenue) : null,
      },
      tickets: {
        value: currentTickets,
        changePercent:
          previousTickets !== null ? this.percentChange(currentTickets, previousTickets) : null,
      },
    };
  }

  // ==================== TREND BREAKDOWN (FOR CHARTS) ====================
  /**
   * Revenue/tickets over time within the selected range, bucketed at
   * a granularity that fits the window size (day/week/month/year).
   */
  public async getTrendBreakdown(
    range: DashboardRange,
    dateRange: DashboardDateRange
  ): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const { groupId, label, sort } = this.getTrendGrouping(range);
    const dateMatch = buildDateMatch("createdAt", dateRange.current);

    // Tickets-per-bucket: join-free, same reasoning as
    // getRevenueAndTicketsStats — must match the headline ticket
    // count, which doesn't depend on the event/ticket still existing.
    const ticketsByBucketPromise = this.transactionModel.aggregate([
      { $match: { status: "completed", ...(dateMatch || {}) } },
      {
        $project: {
          groupKey: groupId,
          ticketsSold: { $size: "$buyers" },
        },
      },
      { $group: { _id: "$groupKey", tickets: { $sum: "$ticketsSold" } } },
    ]);

    // Revenue-per-bucket: needs the join for price, so it can
    // under-count buckets containing only orphaned transactions —
    // same inherent limitation as the headline revenue figure.
    const revenueByBucketPromise = this.transactionModel.aggregate([
      { $match: { status: "completed", ...(dateMatch || {}) } },
      {
        $lookup: {
          from: "events",
          localField: "event",
          foreignField: "_id",
          as: "eventData",
        },
      },
      { $unwind: "$eventData" },
      { $unwind: "$eventData.tickets" },
      { $match: { $expr: { $eq: ["$ticket", "$eventData.tickets._id"] } } },
      {
        $project: {
          groupKey: groupId,
          revenue: {
            $multiply: [{ $size: "$buyers" }, "$eventData.tickets.price"],
          },
        },
      },
      { $group: { _id: "$groupKey", revenue: { $sum: "$revenue" } } },
    ]);

    const [ticketsByBucket, revenueByBucket] = await Promise.all([
      ticketsByBucketPromise,
      revenueByBucketPromise,
    ]);

    // Merge the two by their underlying date key (not just the
    // display label) to avoid any chance of label collisions.
    const merged = new Map<string, { id: any; revenue: number; tickets: number }>();

    ticketsByBucket.forEach((d: any) => {
      const key = JSON.stringify(d._id);
      merged.set(key, { id: d._id, revenue: 0, tickets: d.tickets });
    });
    revenueByBucket.forEach((d: any) => {
      const key = JSON.stringify(d._id);
      const existing = merged.get(key);
      if (existing) {
        existing.revenue = d.revenue;
      } else {
        merged.set(key, { id: d._id, revenue: d.revenue, tickets: 0 });
      }
    });

    const trend: TrendPoint[] = Array.from(merged.values())
      .sort((a, b) => {
        for (const sortKey of Object.keys(sort)) {
          const field = sortKey.replace("_id.", "");
          const diff = (a.id[field] ?? 0) - (b.id[field] ?? 0);
          if (diff !== 0) return diff;
        }
        return 0;
      })
      .map((d) => ({
        label: label(d.id),
        revenue: d.revenue,
        tickets: d.tickets,
      }));

    return { trend };
  }

  // ==================== CONVERSION RATE (SELL-THROUGH) ====================
  /**
   * Tickets sold in the selected range as a share of total ticket
   * inventory across published events. This is sell-through, not
   * funnel conversion (there's no page-view tracking in this stack
   * to measure visits -> purchases).
   */
  public async getConversionRates(dateRange: DashboardDateRange): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const [totalAvailableTickets] = await this.eventModel.aggregate([
      { $match: { published: true } },
      { $unwind: "$tickets" },
      { $group: { _id: null, totalTickets: { $sum: "$tickets.initialQuantity" } } },
    ]);
    const totalTicketsAvailable = totalAvailableTickets?.totalTickets || 0;

    const ticketsSoldInWindow = async (window: DashboardDateRange["current"] | null) => {
      if (!window) return 0;
      const dateMatch = buildDateMatch("createdAt", window);
      const [result] = await this.transactionModel.aggregate([
        { $match: { status: "completed", ...(dateMatch || {}) } },
        { $group: { _id: null, ticketsSold: { $sum: { $size: "$buyers" } } } },
      ]);
      return result?.ticketsSold || 0;
    };

    const [currentSold, previousSold] = await Promise.all([
      ticketsSoldInWindow(dateRange.current),
      dateRange.previous ? ticketsSoldInWindow(dateRange.previous) : Promise.resolve(null),
    ]);

    const currentConversion =
      totalTicketsAvailable === 0 ? 0 : (currentSold / totalTicketsAvailable) * 100;
    const previousConversion =
      previousSold === null
        ? null
        : totalTicketsAvailable === 0
        ? 0
        : (previousSold / totalTicketsAvailable) * 100;

    return {
      conversion: {
        value: Number(currentConversion.toFixed(2)),
        changePercent: this.percentChange(currentConversion, previousConversion),
      },
    };
  }

  // ==================== CHECK-IN RATE ====================
  /**
   * What fraction of sold tickets were actually used, for events that
   * have already ended within the selected window. An event still
   * upcoming always shows 0% checked in, which isn't meaningful yet,
   * so it's excluded rather than dragging the rate down.
   */
  public async getCheckInStats(dateRange: DashboardDateRange): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const now = new Date();
    const endDateMatch: any = { $lt: now };
    if (dateRange.current.start) endDateMatch.$gte = dateRange.current.start;

    const pastEventIds = await this.eventModel
      .find({ "eventDetails.endDate": endDateMatch })
      .distinct("_id");

    if (pastEventIds.length === 0) {
      return {
        checkInStats: { totalSold: 0, totalCheckedIn: 0, checkInRate: 0, eventsConsidered: 0 },
      };
    }

    const [result] = await this.transactionModel.aggregate([
      { $match: { status: "completed", event: { $in: pastEventIds } } },
      { $unwind: "$buyers" },
      {
        $group: {
          _id: null,
          totalSold: { $sum: 1 },
          totalCheckedIn: { $sum: { $cond: [{ $eq: ["$buyers.checkedIn", true] }, 1, 0] } },
        },
      },
    ]);

    const totalSold = result?.totalSold || 0;
    const totalCheckedIn = result?.totalCheckedIn || 0;
    const checkInRate = totalSold > 0 ? (totalCheckedIn / totalSold) * 100 : 0;

    return {
      checkInStats: {
        totalSold,
        totalCheckedIn,
        checkInRate: Number(checkInRate.toFixed(2)),
        eventsConsidered: pastEventIds.length,
      },
    };
  }

  // ==================== PAYMENT HEALTH ====================
  public async getPaymentHealthStats(dateRange: DashboardDateRange): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const dateMatch = buildDateMatch("createdAt", dateRange.current);

    const results = await this.transactionModel.aggregate([
      ...(dateMatch ? [{ $match: dateMatch }] : []),
      { $group: { _id: "$status", count: { $sum: 1 } } },
    ]);

    const counts: Record<string, number> = { completed: 0, pending: 0, failed: 0 };
    results.forEach((r: any) => {
      if (r._id in counts) counts[r._id] = r.count;
    });

    const total = counts.completed + counts.pending + counts.failed;
    const completionRate = total > 0 ? (counts.completed / total) * 100 : 0;

    return {
      paymentHealth: {
        totalCompleted: counts.completed,
        totalPending: counts.pending,
        totalFailed: counts.failed,
        completionRate: Number(completionRate.toFixed(2)),
      },
    };
  }

  // ==================== INFLUENCER ATTRIBUTION ====================
  public async getInfluencerStats(dateRange: DashboardDateRange): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const dateMatch = buildDateMatch("createdAt", dateRange.current);

    const results = await this.transactionModel.aggregate([
      { $match: { status: "completed", ...(dateMatch || {}) } },
      {
        $lookup: {
          from: "events",
          localField: "event",
          foreignField: "_id",
          as: "eventData",
        },
      },
      { $unwind: "$eventData" },
      {
        $addFields: {
          ticketInfo: {
            $first: {
              $filter: {
                input: "$eventData.tickets",
                as: "t",
                cond: { $eq: ["$$t._id", "$ticket"] },
              },
            },
          },
          quantity: { $size: "$buyers" },
        },
      },
      {
        $group: {
          _id: { $cond: [{ $ne: ["$influencer", null] }, "influencer", "organic"] },
          revenue: { $sum: { $multiply: ["$quantity", "$ticketInfo.price"] } },
          tickets: { $sum: "$quantity" },
        },
      },
    ]);

    let influencerRevenue = 0;
    let influencerTickets = 0;
    let organicRevenue = 0;
    let organicTickets = 0;

    results.forEach((r: any) => {
      if (r._id === "influencer") {
        influencerRevenue = r.revenue;
        influencerTickets = r.tickets;
      } else {
        organicRevenue = r.revenue;
        organicTickets = r.tickets;
      }
    });

    const totalRevenue = influencerRevenue + organicRevenue;
    const influencerRevenueSharePercent =
      totalRevenue > 0 ? (influencerRevenue / totalRevenue) * 100 : 0;

    return {
      influencerStats: {
        influencerRevenue,
        influencerTickets,
        organicRevenue,
        organicTickets,
        influencerRevenueSharePercent: Number(influencerRevenueSharePercent.toFixed(2)),
      },
    };
  }

  // ==================== TICKET SALE WINDOW STATUS ====================
  /**
   * A live snapshot of ticket sale windows right now — deliberately
   * NOT scoped to the selected range, since "on sale" is a current
   * state, not a historical one.
   */
  public async getTicketSaleWindowStats(): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const now = new Date();
    const events = await this.eventModel.find({ published: true }).select("tickets").lean();

    const stats: TicketSaleWindowStats = {
      onSale: 0,
      notYetOpen: 0,
      closed: 0,
      noWindowSet: 0,
    };

    for (const event of events) {
      for (const ticket of event.tickets || []) {
        const start = (ticket as any).saleStartDate ? new Date((ticket as any).saleStartDate) : null;
        const end = (ticket as any).saleEndDate ? new Date((ticket as any).saleEndDate) : null;

        if (!start && !end) {
          stats.noWindowSet++;
        } else if (start && now < start) {
          stats.notYetOpen++;
        } else if (end && now > end) {
          stats.closed++;
        } else {
          stats.onSale++;
        }
      }
    }

    return { ticketSaleWindowStats: stats };
  }

  // ==================== COMBINED ANALYTICS ====================
  /**
   * Get all analytics data in a single call, scoped to the given
   * range — same range system as the dashboard (month / 3months /
   * year / all), defaulting to "all".
   */
  public async getAllAnalytics(range: DashboardRange = "all"): Promise<AnalyticsResult> {
    await this.ensureConnection();

    const dateRange = getDashboardDateRange(range);

    const [
      eventStats,
      revenueTicketsData,
      trendData,
      conversionData,
      checkInData,
      paymentHealthData,
      influencerData,
      ticketSaleWindowData,
    ] = await Promise.all([
      this.getEventTicketStats(dateRange),
      this.getRevenueAndTicketsStats(dateRange),
      this.getTrendBreakdown(range, dateRange),
      this.getConversionRates(dateRange),
      this.getCheckInStats(dateRange),
      this.getPaymentHealthStats(dateRange),
      this.getInfluencerStats(dateRange),
      this.getTicketSaleWindowStats(),
    ]);

    return {
      range,
      ...eventStats,
      ...revenueTicketsData,
      ...trendData,
      ...conversionData,
      ...checkInData,
      ...paymentHealthData,
      ...influencerData,
      ...ticketSaleWindowData,
    };
  }
}